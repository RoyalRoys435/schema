myfruitlist = ["cherry,apple,banana"]
print(myfruitlist)
print(type(myfruitlist))

print(myfruitlist[0])

myfruitlist[0] = ("orrange")
print(myfruitlist)

myfinalanswertuple = ("apple", "banana", "pineapple")
print(myfinalanswertuple)


myfavouritefruitdictionary = {
    "akua" : "apple",
    "saanvi" : "banana",
    "paulo" : "apple"
}
print(myfavouritefruitdictionary)

print(myfavouritefruitdictionary["akua"])
