aminoacids = [1,24]
print(aminoacids)
