name = "john"
print("hello" + name + ".")
age = 40

print(name + "is" + str(age) + "years old.")
